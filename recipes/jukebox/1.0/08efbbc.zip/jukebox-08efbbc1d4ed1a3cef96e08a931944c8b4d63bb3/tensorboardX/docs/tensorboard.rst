tensorboardX
===================================
.. automodule:: tensorboardX

.. autoclass:: SummaryWriter
    :members:
    
    .. automethod:: __init__

.. autoclass:: TorchVis
    :members:

    .. automethod:: __init__