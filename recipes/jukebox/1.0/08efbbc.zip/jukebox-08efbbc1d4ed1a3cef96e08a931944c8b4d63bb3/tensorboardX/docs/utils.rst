Helper functions
===================================
.. autofunction:: tensorboardX.utils.figure_to_image